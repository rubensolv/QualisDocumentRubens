# UFVMastersTemplate2021
LaTeX master's thesis template formatted according to the requirements of Universidade Federal de Viçosa (2021)

Updated by me and [Gabriel Franco](https://github.com/gaabrielfranco)
